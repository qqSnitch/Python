import cgi
form = cgi.FieldStorage()